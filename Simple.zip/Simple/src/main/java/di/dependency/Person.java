package di.dependency;

public class Person {
	public static void main(String[] args) {
		
		Car car = new Car();
		
		System.out.println( car.getTire() );
		
	}
}
