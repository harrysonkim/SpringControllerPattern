package dept.dao.face;

import java.util.List;

import dept.dto.Dept;

public interface DeptDao {

	/**
	 *	 
	 *
	 */
	public List<Dept> selectAll();
	
}
